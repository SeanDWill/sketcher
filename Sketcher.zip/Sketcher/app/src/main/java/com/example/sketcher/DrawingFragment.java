package com.example.sketcher;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DrawingFragment extends Fragment {
    private Activity containerActivity; // Activity to which this fragment is contained in
    private FragmentTransaction fragTransaction; // Reference to the fragmentTransaction
    private DrawingView ourDrawing; // Refernce to the drawing activity we will be utilizing
    private LinearLayout drawLayout; // LL for the drawing to occur on
    private File ourImage; // FIle for the image

    /**
     * Constructor for this fragment
     */
    public DrawingFragment(){
    }

    @Override
    public void onPause(){
        super.onPause();
    }


    /**
     * This method is used to add the drawing layout to this fragment
     */
    public void setDrawingView(){
        ourDrawing = new DrawingView(containerActivity, null);
        drawLayout.addView(ourDrawing);
    }

    /**
     * Change the color call made to the DrawingView
     */
    public void changeColor(int newColor){
        ourDrawing.changeColor(newColor);
    }

    /**
     * Change the stroke call made to the DrawingView
     */
    public void changeStroke(float newStroke){
        ourDrawing.changeStroke(newStroke);
    }

    /**
     * This method will be used to set refernces to the proper activity and FragmentTransaction to
     * reference
     * @param containerActivity Activity refernce to the activity in which this is stored
     * @param fragTrans FragmentTransaction to reference the one that was created in the view that
     *                  called this function
     */
    public void setContainerActivity(Activity containerActivity, FragmentTransaction fragTrans) {
        this.containerActivity = containerActivity;
        this.fragTransaction = fragTrans;
    }

    /**
     * This method is used to set the Layout to refernce
     * @param ll LinearLayout, the layout to refernce in this fragment
     */
    public void setLayout(LinearLayout ll){
        drawLayout = ll;
    }


    /**
     * Override method used to set the contact_row and attach the *********
     * @param inflater LayoutInflater used to inflate the contact_row
     * @param container ViewGroup of where the view is contained
     * @param savedInstanceState Bundle of the instance state
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.drawing_frag_layout, container, false);
        return v;
    }

    /**
     * Clear the canvas call made to the DrawingView
     */
    public void setNew(){
        ourDrawing.startNew();
    }

    /**
     * This method will be used in creating the view and returning the uri needed in sending the
     * image
     * @return Uri. needed for the sending of content drawn
     */
    public Uri establishUri() {
        LinearLayout view = containerActivity.findViewById(R.id.drawing);
        Bitmap bitmap = ourDrawing.getBitmap();
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        File f = createImageFile();
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(f);
            bitmap.compress(Bitmap.CompressFormat.PNG, 30 /*ignored for PNG*/, fos);
            fos.flush();
            Uri uri = FileProvider.getUriForFile(
                    containerActivity, "com.example.sketcher.drawingfragment", f);
            fos.close();
            return uri;

        }
        catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    /**
     * his code was supplied from by Professor Ben Dicken
     * This is used in creating image files to be used in order to store data
     * @return File, basic file used in processing current photo of bitmap drawing
     */
    private File createImageFile()  {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format( new Date());
        String imageFileName = "JPEG_"+timeStamp+"_";
        File storageDir = containerActivity.getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = null;
        try {
            image = File.createTempFile(imageFileName, ".jpg", storageDir);
        } catch (IOException e) {
            e.printStackTrace();
        }
        ourImage = image;
        return image;
    }

    /**
     * Getter method used to grab the current photo file
     * @return File, the current drawing as a FIle
     */
    public File getImage(){
        return ourImage;
    }

}
