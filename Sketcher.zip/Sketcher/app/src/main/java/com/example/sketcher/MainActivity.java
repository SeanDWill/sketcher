package com.example.sketcher;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Name: Sean Williams
 * Course: CSC 317
 * Instructor: Ben Dicken
 */
public class MainActivity extends AppCompatActivity {

    private FragmentTransaction fragTransaction; // FragmentTransaction used to manage new fragments
    private DrawingFragment df; // Our drawingFragment to reference
    private ContactsFragment cf;// our OntactsFragment to reference

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();
        df = new DrawingFragment();
        LinearLayout hold = findViewById(R.id.drawing);
        if (hold != null) {
            df.setContainerActivity(this, fragTransaction);
            df.setLayout(hold);
            df.setDrawingView();
            fragTransaction = getSupportFragmentManager().beginTransaction();
            fragTransaction.replace(R.id.outerMostLinearLayout, df);
            fragTransaction.addToBackStack(null);
            fragTransaction.commit();
        }
    }

    /**
     * onClick method to "share" the drawing with our email contacts
     * @param v Button "share"
     */
    public void contactFrag(View v){
        Uri hold = df.establishUri();
        cf = new ContactsFragment(this);
        cf.setUri(hold);
        cf.setFile(df.getImage());
        fragTransaction = getSupportFragmentManager().beginTransaction();
        fragTransaction.replace(df.getId(),cf);
        fragTransaction.addToBackStack(null);
        fragTransaction.commit();

    }

    /**
     * onClick method call to clear the drawing
     * @param v Button
     */
    public void setNewDrawing(View v){
        df.setNew();
    }

    /**
     * onClick method call to change the color of the drawing
     * @param v Button
     */
    public void redColor(View v){
        df.changeColor(Color.RED);
    }

    /**
     * onClick method call to change the color of the drawing
     * @param v Button
     */
    public void greenColor(View v){
        df.changeColor(Color.GREEN);
    }

    /**
     * onClick method call to change the color of the drawing
     * @param v Button
     */
    public void blueColor(View v){
        df.changeColor(Color.BLUE);
    }

    /**
     * onClick method call to change the color of the drawing
     * @param v Button
     */
    public void purpColor(View v){
        df.changeColor(Color.MAGENTA);
    }

    /**
     * onClick method call to change the stroke of the drawing
     * @param v Button
     */
    public void smallStroke(View v){
        df.changeStroke(15.0f);
    }

    /**
     * onClick method call to change the stroke of the drawing
     * @param v Button
     */
    public void medStroke(View v){
        df.changeStroke(35.0f);
    }

    /**
     * onClick method call to change the stroke of the drawing
     * @param v Button
     */
    public void largeStroke(View v){
        df.changeStroke(60.0f);
    }
}
