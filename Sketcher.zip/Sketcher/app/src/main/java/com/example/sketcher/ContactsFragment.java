package com.example.sketcher;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.core.content.FileProvider;
import androidx.fragment.app.Fragment;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

public class ContactsFragment extends Fragment {

    private Activity containerActivity = null;
    private View inflatedView = null;

    private ListView contactsListView;
    private ArrayAdapter<String> contactsAdapter = null;
    private ArrayList<String> contacts = new ArrayList<String>();

    private HashMap<String, String> myHasMap;
    private Uri ourUri;
    private File ourFile;

    /**
     * Constructor method
     * @param containerActivity activity for which to reference
     */
    public ContactsFragment(Activity containerActivity) {
        this.containerActivity = containerActivity;
        myHasMap = new HashMap<String, String>();
    }

    /**
     * Setter method to reference the correct Uri
     * @param uri
     */
    public void setUri(Uri uri) {
        this.ourUri = uri;
    }

    /**
     * Setter method to reference the correct photo File
     * @param inFile
     */
    public void setFile(File inFile){
        ourFile = inFile;
    }


    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {
        inflatedView = inflater.inflate(R.layout.contact_row, container, false);
        return inflatedView;
    }

    @Override
    public void onCreate(Bundle savedInstance){
        super.onCreate(savedInstance);
        getContacts();
    }

    @Override
    public void onResume() {
        super.onResume();
        setupContactsAdapter();
    }

    /**
     * This method will be used to get all of the contacts of the user from their contacts list
     * and add them to a HasMap in format   <STRING, STRING>
     *                                      <CONTACT_ID, EMAIL>
     */
    public void getContacts() {
        int limit = 1000;
        Cursor cursor = containerActivity.getContentResolver().query(
                ContactsContract.Contacts.CONTENT_URI,null, null, null, null);
        while (cursor.moveToNext() && limit > 0) {
            String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
            String given = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            String contact =  given + " :: " + contactId;
            contacts.add(contact);
            Cursor emails = getActivity().getContentResolver().query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI, null,
                    ContactsContract.CommonDataKinds.Email.CONTACT_ID + " = " + contactId, null, null);
            if (emails.moveToNext()) {
                String email = emails.getString(emails.getColumnIndex(ContactsContract.CommonDataKinds.Email.ADDRESS));
                //this.emails.add(email);
                myHasMap.put(contactId,email);
            }
            emails.close();
            limit--;
        }
        cursor.close();
    }

    /**
     * This method will set the contacts ArayAdapter to the ListView
     */
    private void setupContactsAdapter() {
        contactsListView = containerActivity.findViewById(R.id.contact_list_view);
        contactsAdapter = new
                ArrayAdapter<String>(containerActivity, R.layout.fragment_contacts,
                R.id.text_row_text_view, contacts);
        contactsListView.setAdapter(contactsAdapter);
        contactsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            //Method used to select the item selected from the list view (contact to send to)
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("vnd.android.cursor.dir/email");
                TextView tv = view.findViewById(R.id.text_row_text_view);
                String contactId = tv.getText().toString();
                char[] charArray = contactId.toCharArray();
                char ID = charArray[charArray.length-1];
                String idKey = Character.toString(ID);
                intent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[] { myHasMap.get(idKey) });
                //intent.setData(Uri.parse("mailto:"+emails.get(position)));
                Uri uri = FileProvider.getUriForFile(containerActivity,
                        "com.example.sketcher.drawingfragment", ourFile);
                intent.putExtra(android.content.Intent.EXTRA_STREAM, uri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(intent);
            }
        });
    }



}